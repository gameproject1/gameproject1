
#include <stdio.h>
#include <stdlib.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
#include <SDL/SDL_ttf.h>
#include "jeux.h"


		void gestion_vie (hero *thief ,int *k , int *k1 ,  SDL_Surface *ecran , int *run,SDL_Color rouge )
{
		if (thief->nombre_vie==2 && (*k)==0)
		{

	thief->affichage_vie=IMG_Load("vie 3.png");
	(*k)=1;

	}

	if (thief->nombre_vie==1 && (*k1)==0)
	{thief->affichage_vie=IMG_Load("vie 2.png");
	(*k1)=1;
	}

	if (thief->nombre_vie==0)
	{

	thief->affichage_vie=IMG_Load("vie 1.png");
	ezdin->affichage_hero=IMG_Load("thief.png");
Afficher_Personnage (thief , ecran);
(*run)=gameover_game(thief->score);
//printf("run %d\n",(*run));
		;
		SDL_Flip(ecran);
		SDL_Delay(1000);

	}

}
