#ifndef FONCTIONS_H_
#define FONCTIONS_H_
#include <stdio.h>
#include <stdlib.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
#include <SDL/SDL_ttf.h>

typedef struct save_load
{
	SDL_Rect pos_ezdin_map;
	SDL_Rect cam;
	int s1,s2,m1,m2,h1,h2;
	int nv;
	int scor;
	int changer_pour_sauvgarder;
	SDL_Surface *menu_save;
	SDL_Surface *saved;
	SDL_Surface *save;
	SDL_Surface *quit;
	SDL_Surface *resume;
	SDL_Surface *options;
	SDL_Surface *yes1;
	SDL_Surface *yes2;
	SDL_Surface *no1;
	SDL_Surface *no2;
	SDL_Surface *fleche;
	int changes;
	int changer_ecran;
	SDL_Surface *fond;
	int parolechanger;
	int positiondeloha;
	int affichageducoin;

	
}save_load;


typedef struct Radar
{
SDL_Surface *affichage_hero ; 
SDL_Rect position_hero ; 
SDL_Rect frame ; 
}radar ;





typedef struct joueur
{
	char name[20];
	char score[20];
	char time[256];
	
}joueur;


typedef struct maps
{
	SDL_Surface *calque;

	SDL_Surface *affichage_map;
	int  speed_camera;
	SDL_Rect camera;
	double a;
	double v;
	double ajouter_speed;
	
int buttoncamera;
int mouvement_personnage;
int changer;
}maps;

typedef struct temps
{
	int heur1;
	int heur2;
	int minute1;
	int minute2;
	int seconde1;
	int seconde2;
int heurd1;
	int heurd2;
	int minuted1;
	int minuted2;
	int seconded1;
	int seconded2;
	SDL_Surface *temp;
	SDL_Rect position_temp;
	TTF_Font *police;
	int tempactuel;
	int tempprecedent;
	char chaine[20];

	
}temps;


typedef struct paroles
{
	TTF_Font *policeparole;
	char parole1[200];
	char parole2[200];
	char parole3[20];
	int changer;
	char *paroleaffichage;
	char *paroleaffichage2;
	SDL_Surface *affichageparole;
	SDL_Surface *bulle;
	SDL_Surface *affichageparole2;
	SDL_Surface *bulle2;
	SDL_Rect position_parole;
	int taille1;
	int taille2;
	int taille3;
	int changer_qui_parle;
	
}paroles;


typedef struct hero
{
	int changervie1;
int changervie2;
int changervie3;
	
int nombre_vie;

SDL_Surface *affichage_vie;

SDL_Rect position_vie;
SDL_Surface *cadre;

int score;

SDL_Surface *score_affichage;

TTF_Font *policescore;
TTF_Font *policegame;
char scorechaine[25];
int aux;
SDL_Rect position_hero;
SDL_Rect position_aux;
SDL_Surface *win_or_lose;
SDL_Rect win_or_lose_position;
SDL_Rect frame;

int tempprecedentezdin;

SDL_Surface *affichage_hero;

SDL_Rect position_map;
int temp2;
int speed;

int button;

int curframe;

int maxframe;

int activer_defaut;

int curframe2;

int maxframe2;

int sens;

int clavierdown;

} hero;



typedef struct entite_secondaire
{
	SDL_Rect position_entite;
	SDL_Rect position_map;
SDL_Surface *affichage_secondaire;
SDL_Rect frame;
int affichage_ou_non;
int position_aleatoire_max_x;
int position_aleatoire_max_y;
int position_aleatoire_min_x;
int position_aleatoire_min_y;
int frameup;
int framedown;
int frameleft;
int frameright;
SDL_Rect pos_affichage;
int curframe;
int maxframe;
int choix;
int position_max_x;
int position_min_x;
int position_min_y;
int position_max_y;
} entite_secondaire;






typedef struct enigmes
{
	SDL_Rect position_enigme;
SDL_Surface *affichage_enigme;
int choix;
int resultat;
int s1;
int s2;
int m1;
int m2;
SDL_Surface *alpha1;
SDL_Surface *alpha2;
SDL_Surface *alpha3;

} enigmes;

struct Circle
{
 int r;
}typedef Circle;



typedef struct rect_collision 
{

 int hauteur ; 
int largeur ; 
SDL_Rect position; 
} rect_collision;

int magic(SDL_Surface *ecran);
int save_name(SDL_Surface *ecran);
int continues(SDL_Surface *ecran);
int jouer_single(int x,SDL_Surface *ecran);

int Collisiontrigo(SDL_Rect position,SDL_Rect positioncercle,Circle C);

int button(int tabutton[],SDL_Surface *ecran);

int gameover_game(int score);

int win(int scorefinal, temps temp);

void save (hero ezdin , temps temp , maps map , save_load sav , entite_secondaire entite[] , paroles parole, int ligne);

void load_game (hero *ezdin ,temps *temp ,maps *map ,save_load *sav, entite_secondaire entite[] , paroles *parole ,int ligne );

save_load inisaliser_save_load (save_load sav);

paroles inisaliser_parole (paroles parole);

void condition_souris (int clique , int c , SDL_Rect *position_clique, hero *ezdin , maps *map);

void souris (SDL_Rect position_clique , hero ezdin , int *clique , int *c);

void position_entite_sur_map (entite_secondaire entite[]) ;

temps inisaliser_temp (temps temp);

maps Initialiser_map (maps map);

hero Initialiser_Personnage (hero ezdin);

void Afficher_Personnage (hero *ezdin , SDL_Surface *ecran);

void temp_affichage (hero *ezdin, temps *temp, int affichagetemp , SDL_Color rouge ,SDL_Surface *ecran );

void finanimation (hero *ezdin);

void initialiser_entite_secondaire (entite_secondaire entite[],int n) ;

void afficher_entite_secondaire (entite_secondaire entite, SDL_Surface *ecran) ;

enigmes inisaliser_enigme (enigmes enigme);

int aleatoire_enigme(int nombre);

void affichage_enigme (enigmes enigme, SDL_Surface *ecran);

void gestion_vie (hero *ezdin ,int *k , int *k1 ,  SDL_Surface *ecran , int *run,SDL_Color rouge );

void clavier (enigmes *enigme , SDL_Surface *ecran) ;

int Collision_Bounding_Box (SDL_Rect rec1 ,SDL_Rect position_obstacle, int d) ;

int Collision_trigonometrique (hero ezedin , SDL_Rect position_obstacle , int r);

void deplacment_Personnage_clavier (hero *ezdin );

void animation_Personnage (hero *ezdin);

void scrolling (maps *map , SDL_Surface *ecran , hero *ezdin);

void animation_entite (entite_secondaire *entite );

int collision (SDL_Rect * rec1,SDL_Rect* rec2);

void deplacement_entite_x (entite_secondaire *entite);

void deplacement_entite_y (entite_secondaire *entite);

int deplacement_aleatoire ( int positionmax, int positionmin   );

int collision_Parfaite(SDL_Surface *calque , hero ezdin ,int decalage,int d);

SDL_Color GetPixel(SDL_Surface *surface,int x,int y);

void acceleration( hero *ezdin,maps *map,int t);

int multi(SDL_Surface *ecran);

void radar_map (SDL_Surface *map ,hero *ezdin, radar *radar,SDL_Surface *ecran )  ; 

radar initialiser_hero_sur_radar (radar r,hero ezdin) ; 

#endif /* FONCTIONS_H_ */
