#include "jeux.h"
int main()
{
SDL_Surface*ecran=NULL,*img=NULL,*img1=NULL;
img=IMG_Load("vie 1.png");
img1=IMG_Load("map.jpg");
SDL_Rect positionecran,positionvie;
positionecran.x=0;
positionecran.y=0;
positionvie.x=10;
positionvie.y=10;
ecran=SDL_SetVideoMode(1920,1080,32,SDL_HWSURFACE |SDL_DOUBLEBUF);
int run=1;
SDL_Event event;
while (run)
{
SDL_WaitEvent(&event);
switch(event.type)
{
case SDL_QUIT :
run=0;
break;
}
SDL_BlitSurface(img1,NULL,ecran,&positionecran);
SDL_Flip(ecran);
SDL_BlitSurface(img,NULL,ecran,&positionvie);
SDL_Flip(ecran);
}

SDL_FreeSurface(ecran);



return 0;
}
