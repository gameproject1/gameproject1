#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
#include "animation.h"

void initialiser_entite(entite *cd,entite *cg,entite *dc, entite *dop)
	{

	cd->image=NULL ; 
	cd->image=IMG_Load("cameradroite.png");
	cd->pos_image.x=1355 ; 
	cd->pos_image.y=0 ; 

	cg->image=NULL ; 
	cg->image=IMG_Load("cameragauche.png");
	cg->pos_image.x=1355 ; 
	cg->pos_image.y=0 ; 

	dc->image=NULL ; 
	dc->image=IMG_Load("doorclose.png");
	dc->pos_image.x=5500 ; 
	dc->pos_image.y=241 ; 

	dop->image=NULL ; 
	dop->image=IMG_Load("dooropen.png");
	dop->pos_image.x=5500 ; 
	dop->pos_image.y=241 ; 

	}

         void affichage_entite(SDL_Surface *screen,entite *cd,entite *cg,entite *dc, entite *dop)
	{
	int continuer=1 ;
	SDL_FillRect(screen, NULL,SDL_MapRGB(screen->format,0,0,0));	
	SDL_BlitSurface(cd->image,NULL,screen,&cd->pos_image);
	SDL_BlitSurface(dc->image,NULL,screen,&dc->pos_image);
	
	SDL_Flip(screen);
	usleep(3000000) ; 
	

	SDL_FillRect(screen, NULL,SDL_MapRGB(screen->format,0,0,0));	
	SDL_BlitSurface(dop->image,NULL,screen,&dop->pos_image);
	SDL_BlitSurface(cg->image,NULL,screen,&cg->pos_image);

	SDL_Flip(screen);
	usleep(3000000) ; 
	
	
	}
	

