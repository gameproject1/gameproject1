#include <stdio.h>
#include <stdlib.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_ttf.h>
#include <SDL/SDL_mixer.h>
#include "jeux.h"
#include <string.h>
maps Initialiser_map (maps map)
{
map.speed_camera=10;
map.camera.x=524;
map.camera.y=418;
map.camera.h=600;
map.camera.w=800;
map.buttoncamera=0;
map.a=0;
map.v=5;
map.changer=0;
map.affichage_map=IMG_Load("map.png");

	return map;
}
hero Initialiser_Personnage (hero thief)
{
thief.position_hero.x=375;
thief.position_hero.y=275;
thief.position_aux.x=375;
thief.position_aux.y=275;
thief.position_map.x=5800;
thief.position_map.y=693;
thief.sens=0;
thief.clavierdown=0;
thief.frame.y=49;
thief.frame.x=48;
thief.frame.w=48;
thief.frame.h=48;
thief.nombre_vie=3;
thief.score=0;
thief.score_affichage=NULL;
thief.button=0;
thief.affichage_hero=NULL;
thief.affichage_hero=IMG_Load("ezdin.png");
thief.affichage_vie=NULL;
thief.affichage_vie=IMG_Load("vie3.png");
thief.position_vie.x=620;
thief.position_vie.y=0;
thief.curframe=0;
thief.maxframe=2;
thief.changervie1=0;
thief.changervie2=0;
thief.changervie3=0;
thief.policescore=TTF_OpenFont("arial.ttf",40);
thief.policegame=TTF_OpenFont("arial.ttf",80);
thief.win_or_lose=NULL;
thief.win_or_lose_position.x=200;
thief.win_or_lose_position.y=200;
thief.speed=10;
thief.temp2=0;
strcpy(thief.scorechaine,"000");
thief.activer_defaut=0;
thief.tempprecedentezdin=0;
thief.curframe2=0;
thief.maxframe2=119;
return thief;
}


void Afficher_Personnage (hero *thief , SDL_Surface *ecran)
{
SDL_BlitSurface(thief->affichage_hero,&thief->frame,ecran,&thief->position_hero);
}
void deplacment_Personnage_clavier (hero *thief )

{


switch (thief->button)
{

	case 8:

thief->position_map.y-=thief->speed;


break;
	case 2:

thief->position_map.y+=thief->speed;

break;
	case 6:

thief->position_map.x+=thief->speed;

break;
	case 4:

thief->position_map.x-=thief->speed;

break;

}
}
void scrolling (maps *map , SDL_Surface *ecran , hero *thief)
{
switch(map->buttoncamera)
{
case 2:
	map->camera.y+=map->speed_camera;
break;
case 4:
map->camera.x-=map->speed_camera;
break;
case 6:
map->camera.x+=map->speed_camera;
break;
case 8:
map->camera.y-=map->speed_camera;
break;
}
}
int Collisiontrigo(SDL_Rect position,SDL_Rect positioncercle,Circle C)
{
   int xx,yy,xc,yc;
   xx=position.x;
   yy=position.y;
   xc=positioncercle.x;
   yc=positioncercle.y;
   int d2 = (xx-xc)*(xx-xc) + (yy-yc)*(yy-yc);
   if (d2>C.r*C.r)
//il n'ya pas une collision
      return 0;
   else
// il y'a une collision
      return 1;


void animation_Personnage (hero *thief)
{

	switch(thief->button)
	{

		case 8:
		{




			thief->frame.y=146;
	thief->frame.h=48;
        thief->frame.w=48;
        thief->curframe+=1;

	if(thief->curframe>thief->maxframe)
	{
		thief->curframe=0;
	}

          thief->frame.x=thief->curframe*thief->frame.w;



		}
		break;

		case 2:
		{





				thief->frame.y=0;
	thief->frame.h=48;
thief->frame.w=48;
	

thief->curframe+=1;

	if(thief->curframe>thief->maxframe)
	{
		thief->curframe=0;
	}

thief->frame.x=thief->curframe*thief->frame.w;










		}
		break;

		case 6:
		{





thief->frame.y=97;
	thief->frame.h=48;
thief->frame.w=48;


thief->curframe+=1;

	if(thief->curframe>thief->maxframe)
	{
		thief->curframe=0;
	}
thief->frame.x=thief->curframe*thief->frame.w;







		}
		break;

		case 4:
		{






thief->frame.y=49;
	thief->frame.h=48;
thief->frame.w=49;

thief->curframe+=1;

	if(thief->curframe>thief->maxframe)
	{
		thief->curframe=0;
	}

thief->frame.x=thief->curframe*thief->frame.w;











		}
		break;










	}
	if (thief->activer_defaut>=4)
					{

							thief->frame.y=194;
							thief->curframe2+=1;

	if(thief->curframe2>thief->maxframe2)
	{
		thief->curframe2=0;
	}


thief->frame.x=thief->curframe2*thief->frame.w;

					}







}
















}

