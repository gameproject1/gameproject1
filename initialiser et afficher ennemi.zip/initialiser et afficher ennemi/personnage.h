#include<stdlib.h>
#include<stdio.h>
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<SDL/SDL.h>
#include<SDL/SDL_image.h>
#include<SDL/SDL_ttf.h>
#ifndef DEF_CONSTANTES
#define DEF_CONSTANTES


#define LARGEUR_FENETRE 1000
#define HAUTEUR_FENETRE 1000


#endif
