
#include<stdio.h>
#include<stdlib.h>
#include<SDL/SDL.h>
#include<SDL/SDL_image.h>
 
int main(int argc, char *argv[])
{
int c=1,i;
SDL_Event event;
SDL_Surface *ecran, *drago[12], *fond;
SDL_Surface *actuel;
SDL_Rect position, positionFond;
position.x=65;
position.y=10;
positionFond.x=0;
positionFond.y=0;
SDL_Init(SDL_INIT_VIDEO);
ecran=SDL_SetVideoMode(640,480,32,SDL_HWSURFACE);
SDL_WM_SetCaption("Rpg Sh4rker",NULL);
actuel=IMG_Load("face.png");
drago[1]=IMG_Load("face.png");
drago[2]=IMG_Load("gauche.png");
drago[3]=IMG_Load("droite.png");
drago[4]=IMG_Load("dos.png");
drago[5]=IMG_Load("face2.png");
drago[6]=IMG_Load("face3.png");
drago[7]=IMG_Load("dos2.png");
drago[8]=IMG_Load("dos3.png");
drago[9]=IMG_Load("gauche2.png");
drago[10]=IMG_Load("gauche3.png");
drago[11]=IMG_Load("droite2.png");
drago[12]=IMG_Load("droite3.png");
fond=IMG_Load("fond.bmp");
SDL_BlitSurface(fond,NULL,ecran,&positionFond);
SDL_BlitSurface(actuel,NULL,ecran,&position);
SDL_Flip(ecran);
SDL_EnableKeyRepeat(10, 10);
while(c)
{
SDL_WaitEvent(&event);
    switch(event.type)
    {
        case SDL_QUIT:
            c = 0;
            break;
        case SDL_KEYDOWN:
            switch (event.key.keysym.sym)
            {
                case SDLK_ESCAPE:
                    c = 0;
                    break;
        case SDLK_UP:
            actuel=drago[4];
            position.y--;
            SDL_BlitSurface(fond,NULL,ecran,&positionFond);
            SDL_BlitSurface(actuel,NULL,ecran,&position);
            SDL_Flip(ecran);
            break;
         case SDLK_DOWN:
            actuel=drago[1];
            position.y++;
            SDL_BlitSurface(fond,NULL,ecran,&positionFond);
            SDL_BlitSurface(actuel,NULL,ecran,&position);
            SDL_Flip(ecran);
            break;
          case SDLK_RIGHT:
            actuel=drago[3];
            position.x++;
            SDL_BlitSurface(fond,NULL,ecran,&positionFond);
            SDL_BlitSurface(actuel,NULL,ecran,&position);
            SDL_Flip(ecran);
            break;
          case SDLK_LEFT:
            actuel=drago[2];
            position.x--;
            SDL_BlitSurface(fond,NULL,ecran,&positionFond);
            SDL_BlitSurface(actuel,NULL,ecran,&position);
            SDL_Flip(ecran);
            break;
 
           }
break;
         case SDL_MOUSEBUTTONUP:
if(event.button.x>=position.x)
{
            do{
            actuel=drago[3];
            position.x++;
            SDL_BlitSurface(fond,NULL,ecran,&positionFond);
            SDL_BlitSurface(actuel,NULL,ecran,&position);
            SDL_Flip(ecran);

}
             while(position.x<=event.button.x);
    }
else if(event.button.x<=position.x)
{
            do{
            actuel=drago[2];
            position.x--;
            SDL_BlitSurface(fond,NULL,ecran,&positionFond);
            SDL_BlitSurface(actuel,NULL,ecran,&position);
            SDL_Flip(ecran);

}
             while(position.x>=event.button.x);
    }
else
{
SDL_BlitSurface(fond,NULL,ecran,&positionFond);
SDL_BlitSurface(actuel,NULL,ecran,&position);
SDL_Flip(ecran);
}
break;
}
}
SDL_FreeSurface(ecran);
SDL_FreeSurface(fond);
SDL_FreeSurface(actuel);
SDL_Quit();
return EXIT_SUCCESS;
}


