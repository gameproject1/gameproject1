
#ifndef HEADER_H_INCLUDED
#define HEADER_H_INCLUDED

typedef struct {
	SDL_Surface *personnage;
	SDL_Rect position_personnage;
	}personnage;

typedef struct {
	SDL_Surface *fire;
	SDL_Rect position_fire;
	}fire;

