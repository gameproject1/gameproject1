#ifndef HEADER_H_INCLUDED
#define HEADER_H_INCLUDED
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
typedef struct ob {
	SDL_Surface *image;
	SDL_Rect pos_image;
	}objet;


void initialiser_objet(objet *bijoux,objet *cd,objet *cg,objet *cle,objet *dc, objet *dop,objet *money,objet *password);
void affichage_objet(SDL_Surface *screen,objet *bijoux ,objet *cd, objet *cg, objet *cle, objet *dc, objet *dop, objet *money, objet *password);
#endif
