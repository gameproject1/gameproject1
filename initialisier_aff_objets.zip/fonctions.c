#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
#include "fichier.h"

void initialiser_objet(objet *bijoux ,objet *cd, objet *cg, objet *cle, objet *dc, objet *dop, objet *money, objet *password) 
	{
	bijoux->image=NULL ; 
	bijoux->image=IMG_Load("bijoux.png");
	bijoux->pos_image.x=4754 ; 
	bijoux->pos_image.y=440 ; 
	
	cd->image=NULL ; 
	cd->image=IMG_Load("cameradroite.png");
	cd->pos_image.x=1355 ; 
	cd->pos_image.y=0 ; 

	cg->image=NULL ; 
	cg->image=IMG_Load("cameragauche.png");
	cg->pos_image.x=1355 ; 
	cg->pos_image.y=0 ; 


	cle->image=NULL ; 
	cle->image=IMG_Load("clé.png");
	cle->pos_image.x=364 ; 
	cle->pos_image.y=414 ; 

	dc->image=NULL ; 
	dc->image=IMG_Load("doorclose.png");
	dc->pos_image.x=5756 ; 
	dc->pos_image.y=241 ; 

	dop->image=NULL ; 
	dop->image=IMG_Load("dooropen.png");
	dop->pos_image.x=5756 ; 
	dop->pos_image.y=241 ; 

	money->image=NULL ; 
	money->image=IMG_Load("money.png");
	money->pos_image.x=2953 ; 
	money->pos_image.y=350 ; 

	password->image=NULL ; 
	password->image=IMG_Load("password.png");
	password->pos_image.x=5321 ; 
	password->pos_image.y=350 ; 
	}

void affichage_objet(SDL_Surface *screen,objet *bijoux ,objet *cd, objet *cg, objet *cle, objet *dc, objet *dop, objet *money, objet *password)
	{
	SDL_BlitSurface(bijoux->image,NULL,screen,&bijoux->pos_image);
	SDL_BlitSurface(cd->image,NULL,screen,&cd->pos_image);
	SDL_BlitSurface(cg->image,NULL,screen,&cg->pos_image);
	SDL_BlitSurface(cle->image,NULL,screen,&cle->pos_image);
	SDL_BlitSurface(dc->image,NULL,screen,&dc->pos_image);
	SDL_BlitSurface(dop->image,NULL,screen,&dop->pos_image);
	SDL_BlitSurface(money->image,NULL,screen,&money->pos_image);
	SDL_BlitSurface(password->image,NULL,screen,&password->pos_image);
	
	}


