#include <stdlib.h>
#include <stdio.h>
#include "partage_ecran.h"

background Initialiser_map (background backg)
{

backg.speed_camera1=10;
backg.camera1.x=0;
backg.camera1.y=0;
backg.camera1.h=680;
backg.camera1.w=2880;
backg.positionback1.x=0;
backg.positionback1.y=0;
backg.positionback1.w=2880;
backg.positionback1.h=680;
backg.speed_camera2=10;
backg.camera2.x=0;
backg.camera2.y=0;
backg.camera2.h=680;
backg.camera2.w=2880;
backg.positionback2.x=2880;
backg.positionback2.y=0;
backg.positionback2.w=2880;
backg.positionback2.h=680;
backg.background1=IMG_Load("map.jpg");
return backg;
}




void afficher_background(background backg,SDL_Surface*ecran)
{

SDL_BlitSurface(backg.background1,&backg.camera1,ecran,&backg.positionback1);
SDL_Flip(ecran);
SDL_BlitSurface(backg.background1,&backg.camera2,ecran,&backg.positionback2);
SDL_Flip(ecran);

}
