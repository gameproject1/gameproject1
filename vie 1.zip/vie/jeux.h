#ifndef FONCTIONS_H_
#define FONCTIONS_H_
#include <stdio.h>
#include <stdlib.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
#include <SDL/SDL_ttf.h>

typedef struct save_load
{
	SDL_Rect pos_ezdin_map;
	SDL_Rect cam;
	int s1,s2,m1,m2,h1,h2;
	int nv;
	int scor;
	int changer_pour_sauvgarder;
	SDL_Surface *menu_save;
	SDL_Surface *saved;
	SDL_Surface *save;
	SDL_Surface *quit;
	SDL_Surface *resume;
	SDL_Surface *options;
	SDL_Surface *yes1;
	SDL_Surface *yes2;
	SDL_Surface *no1;
	SDL_Surface *no2;
	SDL_Surface *fleche;
	int changes;
	int changer_ecran;
	SDL_Surface *fond;
	int parolechanger;
	int positiondeloha;
	int affichageducoin;

	
}save_load;


typedef struct Radar
{
SDL_Surface *affichage_hero ; 
SDL_Rect position_hero ; 
SDL_Rect frame ; 
}radar ;





typedef struct joueur
{
	char name[20];
	char score[20];
	char time[256];
	
}joueur;


typedef struct maps
{
	SDL_Surface *calque;

	SDL_Surface *affichage_map;
	int  speed_camera;
	SDL_Rect camera;
	double a;
	double v;
	double ajouter_speed;
	
int buttoncamera;
int mouvement_personnage;
int changer;
}maps;

typedef struct temps
{
	int heur1;
	int heur2;
	int minute1;
	int minute2;
	int seconde1;
	int seconde2;
int heurd1;
	int heurd2;
	int minuted1;
	int minuted2;
	int seconded1;
	int seconded2;
	SDL_Surface *temp;
	SDL_Rect position_temp;
	TTF_Font *police;
	int tempactuel;
	int tempprecedent;
	char chaine[20];

	
}temps;


typedef struct paroles
{
	TTF_Font *policeparole;
	char parole1[200];
	char parole2[200];
	char parole3[20];
	int changer;
	char *paroleaffichage;
	char *paroleaffichage2;
	SDL_Surface *affichageparole;
	SDL_Surface *bulle;
	SDL_Surface *affichageparole2;
	SDL_Surface *bulle2;
	SDL_Rect position_parole;
	int taille1;
	int taille2;
	int taille3;
	int changer_qui_parle;
	
}paroles;


typedef struct hero
{
int changervie1;
int changervie2;
int changervie3;
	
int nombre_vie;

SDL_Surface *affichage_vie;

SDL_Rect position_vie;
SDL_Surface *cadre;

int score;

SDL_Surface *score_affichage;

TTF_Font *policescore;
TTF_Font *policegame;
char scorechaine[25];
int aux;
SDL_Rect position_hero;
SDL_Rect position_aux;
SDL_Surface *win_or_lose;
SDL_Rect win_or_lose_position;

} hero;


int continues(SDL_Surface *ecran);

int gameover_game(int score);

int win(int scorefinal, temps temp);

save_load inisaliser_save_load (save_load sav);

void gestion_vie (hero *ezdin ,int *k , int *k1 ,  SDL_Surface *ecran , int *run,SDL_Color rouge );



#endif /* FONCTIONS_H_ */
