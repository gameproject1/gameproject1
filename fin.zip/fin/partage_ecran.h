#ifndef PARTAGE_ECRANH_H_INCLUDED
#define PARTAGE_ECRANH_H_INCLUDED
#include <stdio.h>
#include <stdlib.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
#include <SDL/SDL_ttf.h>

typedef struct background
{
	SDL_Surface *background1,*background2;
	int  speed_camera1;
        int  speed_camera2;
	SDL_Rect camera1;
	SDL_Rect camera2;
        SDL_Rect positionback1;
	SDL_Rect positionback2;
int button;
}background;

typedef struct personnage
{
SDL_Rect position1;
SDL_Rect position2;
SDL_Surface*image1;
SDL_Surface*image2;


}per;

typedef struct animation
{
	SDL_Surface *tsawer[4];
	SDL_Surface *tsawerL[4];
	SDL_Surface *bg;
	// anim à droite:
	SDL_Surface *imin1;
	SDL_Surface *imin2;
	SDL_Surface *imin3;
	SDL_Surface *imin4;

	// anim à gauche:
	SDL_Surface *issar1;
	SDL_Surface *issar2;
	SDL_Surface *issar3;
	SDL_Surface *issar4;

	SDL_Rect pos_Sprite;
	SDL_Rect pos_bg;
	SDL_Surface *screen;

	int done;
	int direct;

	SDL_Event event_anim;

}animation;

typedef struct ob
{
	SDL_Surface *image;
	SDL_Rect pos_image;
}entite;
background Initialiser_map (background backg);
background Init_map(background backg);
void afficher_background(background backg,SDL_Surface*ecran);
void afficher_background2(background backg,SDL_Surface*ecran);
background scrolling(background backg,SDL_Event e);
background scrolling1(background backg,SDL_Event e);
per initialiser_per(per p);
per initialiser_per2(per p);
void aff(per p,background back,SDL_Surface*ecran);
void aff2(per p,background back,SDL_Surface*ecran);
void anim();
void anim1();

void initialiser_entite(entite *cd,entite *cg,entite *dc, entite *dop);
void affichage_entite(SDL_Surface *ecran,entite *cd,entite *cg,entite 	*dc, entite *dop);
void initialiser_entite1(entite *cd,entite *cg,entite *dc, entite *dop);
void affichage_entite1(SDL_Surface *ecran,entite *cd,entite *cg,entite 	*dc, entite *dop);



#endif // PARTAGE_ECRANH_H_INCLUDED
