#include <stdlib.h>
#include <stdio.h>
#include "partage_ecran.h"

background Initialiser_map (background backg)
{

backg.speed_camera1=10;
backg.camera1.x=0;
backg.camera1.y=0;
backg.camera1.h=680;
backg.camera1.w=2880;
backg.positionback1.x=0;
backg.positionback1.y=0;
backg.positionback1.w=2880;
backg.positionback1.h=680;
backg.speed_camera2=10;
backg.camera2.x=0;
backg.camera2.y=0;
backg.camera2.h=680;
backg.camera2.w=2880;
backg.positionback2.x=2880;
backg.positionback2.y=0;
backg.positionback2.w=2880;
backg.positionback2.h=680;
backg.background1=IMG_Load("map1.jpg");

return backg;
}
/***************************************************************/
void afficher_background(background backg,SDL_Surface*ecran)
{
SDL_BlitSurface(backg.background1,&backg.camera1,ecran,&backg.positionback1);
SDL_Flip(ecran);
}
/***********************************************************/
void afficher_background2(background backg,SDL_Surface*ecran)
{
SDL_BlitSurface(backg.background1,&backg.camera2,ecran,&backg.positionback2);
SDL_Flip(ecran);
}

/*********************************************************/
background scrolling(background backg,SDL_Event e)
{  
SDL_PollEvent(&e);
    switch(e.type)
    {     	
case SDL_KEYDOWN:
    	
  	switch(e.key.keysym.sym)
        {
                   case SDLK_LEFT:
                   backg.camera1.x-=200;
                   break;
                   case SDLK_RIGHT:
                   backg.camera1.x+=200;
                   break;
        }
	
	
	if(backg.camera1.x>=5760)
		backg.camera1.x=5760;
	if(backg.camera1.x<=0)
		backg.camera1.x=0;
    }
return backg;	    	      
}
/***********************************************************/
background scrolling1(background backg,SDL_Event e)
{  
SDL_PollEvent(&e);
    switch(e.type)
    {     	
case SDL_KEYDOWN:
    	
  	switch(e.key.keysym.sym)
        {
                   case SDLK_q:
                   backg.camera2.x-=200;
                   break;
                   case SDLK_d:
                   backg.camera2.x+=200;
                   break;
        }
	
	
	if(backg.camera2.x>=5760)
		backg.camera2.x=5760;
	if(backg.camera2.x<=0)
		backg.camera2.x=0;
    }
return backg;	    	      
}
/***********************************************/
per initialiser_per(per p)
{
p.position1.x=0;
p.position1.y=10;
p.image1=IMG_Load("r1.png");


return p;
}

/********************************************/

per initialiser_per2(per p)
{
p.position2.x=2900;
p.position2.y=10;
p.image2=IMG_Load("r2.png");
return p;
}

void aff(per p,background back,SDL_Surface*ecran)
{
SDL_BlitSurface(p.image1,&back.camera1,ecran,&p.position1);
SDL_Flip(ecran);

}
/*******************************************/
void aff2(per p,background back,SDL_Surface*ecran)
{

SDL_BlitSurface(p.image2,&back.camera2,ecran,&p.position2);
SDL_Flip(ecran);

}

/******************************************/
void anim()
{
	
	animation perso;
        perso.direct = -1;
	perso.imin1=NULL;
	perso.imin2=NULL;
	perso.imin3=NULL;
	perso.imin4=NULL;


	perso.issar1 = NULL;
	perso.issar2 = NULL;
	perso.issar3 = NULL;
	perso.issar4 = NULL;

	perso.screen =NULL;
	perso.bg = IMG_Load("bg6-small.png");
	perso.imin1=IMG_Load("Sans titre -1.png");
	perso.imin2=IMG_Load("Sans titre -2.png");
	perso.imin3=IMG_Load("Sans titre -3.png");
	perso.imin4=IMG_Load("Sans titre -4.png");

	perso.issar1 = IMG_Load("Sans titre 1.png");
	perso.issar2 = IMG_Load("Sans titre 2.png");
	perso.issar3 = IMG_Load("Sans titre 3.png");
	perso.issar4 = IMG_Load("Sans titre 4.png");

	perso.tsawer[0]=perso.imin1;
	perso.tsawer[1]=perso.imin2;
	perso.tsawer[2]=perso.imin3;
	perso.tsawer[3]=perso.imin4;

	perso.tsawerL[0]=NULL;
	perso.tsawerL[1]=NULL;
	perso.tsawerL[2]=NULL;
	perso.tsawerL[3]=NULL;

	perso.tsawerL[0]=perso.issar1;
	perso.tsawerL[1]=perso.issar2;
	perso.tsawerL[2]=perso.issar3;
	perso.tsawerL[3]=perso.issar4;


	perso.pos_bg.x=0;
	perso.pos_bg.y=0;

int i=0;
int j;
	/*if(SDL_Init(SDL_INIT_VIDEO)!=0)
	{
	printf("Unable to initialize SDL: %s\n",SDL_GetError());
	return 1; // : Le jeux se ferme si la la valeure de retour est '1'
	}*/

	perso.screen= SDL_SetVideoMode(1600,800, 32,  SDL_HWSURFACE | SDL_DOUBLEBUF | SDL_RESIZABLE);


perso.done=1;

//SDL_EnableKeyRepeat(10,0);

while(perso.done)
{
	SDL_PollEvent(&perso.event_anim);
	  switch(perso.event_anim.type) 
    {
    case SDL_QUIT: 
    perso.done = 0; 
    break;
    case SDL_KEYDOWN: 
      
      switch(perso.event_anim.key.keysym.sym)
      {
      case SDLK_ESCAPE: 
      perso.done=0;
      break;

      case SDLK_UP: 
      {
      perso.pos_Sprite.y-=2;
  
      }
       break;

      case SDLK_DOWN: // Flèche bas
      {
       perso.pos_Sprite.y+=2;
    
      } 
      break;

      case SDLK_RIGHT: // Flèche droite
      { 
      perso.pos_Sprite.x+=5;
      perso.direct=1;
      i++;
      

    }
       break;

      case SDLK_LEFT: // Flèche gauche
      {
      perso.pos_Sprite.x-=5;
      perso.direct=2;
      i++;
      
      }
      
        break;
                    
      }

    }
    //blit;
    if(i>3)
      {
      	i=0;
      }
    if (perso.direct==1)
    {
    	SDL_BlitSurface(perso.bg , NULL , perso.screen , &perso.pos_bg);
    	SDL_BlitSurface(perso.tsawer[i] , NULL , perso.screen , &perso.pos_Sprite);
    	SDL_Flip(perso.screen);
    }

    else if (perso.direct==2)
    {
    	
    	SDL_BlitSurface(perso.bg , NULL , perso.screen , &perso.pos_bg);
    	SDL_BlitSurface(perso.tsawerL[i] , NULL , perso.screen , &perso.pos_Sprite);
    	SDL_Flip(perso.screen);
    }

}
SDL_FreeSurface(perso.screen);
SDL_FreeSurface(perso.imin1);
SDL_FreeSurface(perso.imin2);
SDL_FreeSurface(perso.imin3);
SDL_FreeSurface(perso.imin4);
SDL_FreeSurface(perso.issar1);
SDL_FreeSurface(perso.issar2);
SDL_FreeSurface(perso.issar3);
SDL_FreeSurface(perso.issar4);
/*for(i=0 ; i<4 ; i++)
{
	SDL_FreeSurface(perso.tsawerL[i]);
	SDL_FreeSurface(perso.tsawer[i]);
}*/
SDL_QUIT;
return 0;
}

/*******************************************/
void anim1()
{
	
	animation perso;
        perso.direct = -1;
	perso.imin1=NULL;
	perso.imin2=NULL;
	perso.imin3=NULL;
	perso.imin4=NULL;


	perso.issar1 = NULL;
	perso.issar2 = NULL;
	perso.issar3 = NULL;
	perso.issar4 = NULL;

	perso.screen =NULL;
	perso.bg = IMG_Load("bg6-small.png");
	perso.imin1=IMG_Load("Sans titre -1.png");
	perso.imin2=IMG_Load("Sans titre -2.png");
	perso.imin3=IMG_Load("Sans titre -3.png");
	perso.imin4=IMG_Load("Sans titre -4.png");

	perso.issar1 = IMG_Load("Sans titre 1.png");
	perso.issar2 = IMG_Load("Sans titre 2.png");
	perso.issar3 = IMG_Load("Sans titre 3.png");
	perso.issar4 = IMG_Load("Sans titre 4.png");

	perso.tsawer[0]=perso.imin1;
	perso.tsawer[1]=perso.imin2;
	perso.tsawer[2]=perso.imin3;
	perso.tsawer[3]=perso.imin4;

	perso.tsawerL[0]=NULL;
	perso.tsawerL[1]=NULL;
	perso.tsawerL[2]=NULL;
	perso.tsawerL[3]=NULL;

	perso.tsawerL[0]=perso.issar1;
	perso.tsawerL[1]=perso.issar2;
	perso.tsawerL[2]=perso.issar3;
	perso.tsawerL[3]=perso.issar4;


	perso.pos_bg.x=2880;
	perso.pos_bg.y=0;

int i=0;
int j;
	/*if(SDL_Init(SDL_INIT_VIDEO)!=0)
	{
	printf("Unable to initialize SDL: %s\n",SDL_GetError());
	return 1; // : Le jeux se ferme si la la valeure de retour est '1'
	}*/

	perso.screen= SDL_SetVideoMode(1600,800, 32,  SDL_HWSURFACE | SDL_DOUBLEBUF | SDL_RESIZABLE);


perso.done=1;

//SDL_EnableKeyRepeat(10,0);

while(perso.done)
{
	SDL_PollEvent(&perso.event_anim);
	  switch(perso.event_anim.type) 
    {
    case SDL_QUIT: 
    perso.done = 0; 
    break;
    case SDL_KEYDOWN: 
      
      switch(perso.event_anim.key.keysym.sym)
      {
      case SDLK_ESCAPE: 
      perso.done=0;
      break;

      case SDLK_UP: 
      {
      perso.pos_Sprite.y-=2;
  
      }
       break;

      case SDLK_DOWN: // Flèche bas
      {
       perso.pos_Sprite.y+=2;
    
      } 
      break;

      case SDLK_RIGHT: // Flèche droite
      { 
      perso.pos_Sprite.x+=5;
      perso.direct=1;
      i++;
      

    }
       break;

      case SDLK_LEFT: // Flèche gauche
      {
      perso.pos_Sprite.x-=5;
      perso.direct=2;
      i++;
      
      }
      
        break;
                    
      }

    }
    //blit;
    if(i>3)
      {
      	i=0;
      }
    if (perso.direct==1)
    {
    	SDL_BlitSurface(perso.bg , NULL , perso.screen , &perso.pos_bg);
    	SDL_BlitSurface(perso.tsawer[i] , NULL , perso.screen , &perso.pos_Sprite);
    	SDL_Flip(perso.screen);
    }

    else if (perso.direct==2)
    {
    	
    	SDL_BlitSurface(perso.bg , NULL , perso.screen , &perso.pos_bg);
    	SDL_BlitSurface(perso.tsawerL[i] , NULL , perso.screen , &perso.pos_Sprite);
    	SDL_Flip(perso.screen);
    }

}
SDL_FreeSurface(perso.screen);
SDL_FreeSurface(perso.imin1);
SDL_FreeSurface(perso.imin2);
SDL_FreeSurface(perso.imin3);
SDL_FreeSurface(perso.imin4);
SDL_FreeSurface(perso.issar1);
SDL_FreeSurface(perso.issar2);
SDL_FreeSurface(perso.issar3);
SDL_FreeSurface(perso.issar4);
/*for(i=0 ; i<4 ; i++)
{
	SDL_FreeSurface(perso.tsawerL[i]);
	SDL_FreeSurface(perso.tsawer[i]);
}*/
SDL_QUIT;
return 0;
}
/***********************************/
void initialiser_entite(entite *cd,entite *cg,entite *dc, entite *dop)
	{

	cd->image=NULL ; 
	cd->image=IMG_Load("cameradroite.png");
	cd->pos_image.x=3500 ; 
	cd->pos_image.y=0 ; 

	cg->image=NULL ; 
	cg->image=IMG_Load("cameragauche.png");
	cg->pos_image.x=3500 ; 
	cg->pos_image.y=0 ; 

	dc->image=NULL ; 
	dc->image=IMG_Load("doorclose.png");
	dc->pos_image.x=5500 ; 
	dc->pos_image.y=241 ; 

	dop->image=NULL ; 
	dop->image=IMG_Load("dooropen.png");
	dop->pos_image.x=5500 ; 
	dop->pos_image.y=241 ; 

	}
/***************************************/
         void affichage_entite(SDL_Surface *ecran,entite *cd,entite *cg,entite *dc, entite *dop)
	{
	int continuer=1 ;
	SDL_FillRect(ecran, NULL,SDL_MapRGB(ecran->format,0,0,0));	
	SDL_BlitSurface(cd->image,NULL,ecran,&cd->pos_image);
	SDL_BlitSurface(dc->image,NULL,ecran,&dc->pos_image);
	
	SDL_Flip(ecran);
	usleep(3000000) ; 
	

	SDL_FillRect(ecran, NULL,SDL_MapRGB(ecran->format,0,0,0));	
	SDL_BlitSurface(dop->image,NULL,ecran,&dop->pos_image);
	SDL_BlitSurface(cg->image,NULL,ecran,&cg->pos_image);

	SDL_Flip(ecran);
	usleep(3000000) ; 
	
	
	}
	
/**************************************/
void initialiser_entite1(entite *cd,entite *cg,entite *dc, entite *dop)
	{

	cd->image=NULL ; 
	cd->image=IMG_Load("cameradroite.png");
	cd->pos_image.x=1355 ; 
	cd->pos_image.y=0 ; 

	cg->image=NULL ; 
	cg->image=IMG_Load("cameragauche.png");
	cg->pos_image.x=1355 ; 
	cg->pos_image.y=0 ; 

	dc->image=NULL ; 
	dc->image=IMG_Load("doorclose.png");
	dc->pos_image.x=2880 ; 
	dc->pos_image.y=241 ; 

	dop->image=NULL ; 
	dop->image=IMG_Load("dooropen.png");
	dop->pos_image.x=2880 ; 
	dop->pos_image.y=241 ; 

	}
/*******************************************/
         void affichage_entite1(SDL_Surface *ecran,entite *cd,entite *cg,entite *dc, entite *dop)
	{
	int continuer=1 ;
	SDL_FillRect(ecran, NULL,SDL_MapRGB(ecran->format,0,0,0));	
	SDL_BlitSurface(cd->image,NULL,ecran,&cd->pos_image);
	SDL_BlitSurface(dc->image,NULL,ecran,&dc->pos_image);
	
	SDL_Flip(ecran);
	usleep(3000000) ; 
	

	SDL_FillRect(ecran, NULL,SDL_MapRGB(ecran->format,0,0,0));	
	SDL_BlitSurface(dop->image,NULL,ecran,&dop->pos_image);
	SDL_BlitSurface(cg->image,NULL,ecran,&cg->pos_image);

	SDL_Flip(ecran);
	usleep(3000000) ; 
	
	
	}
	


