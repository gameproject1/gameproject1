#include <stdlib.h>
#include <stdio.h>
#include "partage_ecran.h"


int main()
{

    SDL_Surface*ecran=NULL;
    background backg;
    per p,p1;
    background backg2;
    backg=Initialiser_map(backg);
    backg2=Initialiser_map(backg);
    p=initialiser_per(p);
    p1=initialiser_per2(p1);
    SDL_Event e;
    int continuer=1;
    SDL_Init(SDL_INIT_EVERYTHING);
    ecran = SDL_SetVideoMode(5760,680, 32, SDL_HWSURFACE );
	entite cd,cg,dop,dc;
	initialiser_entite(&cd,&cg,&dc,&dop);
	initialiser_entite1(&cd,&cg,&dc,&dop);

    while(continuer)
    {
       afficher_background2(backg2,ecran);
       aff2(p1,backg,ecran); 
       backg2=scrolling1(backg2,e);
	anim1();
	affichage_entite1(ecran,&cd,&cg,&dc,&dop);

       afficher_background(backg,ecran); 
       aff(p,backg,ecran);
       backg=scrolling(backg,e);
	anim();
	affichage_entite(ecran,&cd,&cg,&dc,&dop);
       
       
       
        
        SDL_PollEvent(&e);
        switch(e.type)
        {
            case SDL_QUIT:
            continuer=0 ;
            break;
        }


    }
    SDL_Quit();




return 0;
}
