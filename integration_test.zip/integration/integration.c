#include<stdlib.h>
#include<stdio.h>
#include<string.h>
#include <stdlib.h>
#include <stdio.h>
#include <SDL/SDL.h>
#include <SDL/SDL_mixer.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_ttf.h>
#include"integration.h"

int main()
{
objet*bijoux ;
objet*cd;
objet*cg; 
objet*cle; 
objet*dc;
objet*dop;
objet*money; 
objet*password;
        SDL_Surface *screen=NULL;
	SDL_Surface *background;
        entite *cd1;
entite *cg1;
entite *dc1;
entite *dop1;
	SDL_Rect positionecran;
	SDL_Rect positionbackground;
	SDL_Event e;
        SDL_Rect camera;
	int continuer=1;;
//************************************//
        background=IMG_Load("level1complet.jpg");
        SDL_Init(SDL_INIT_EVERYTHING);
        bijoux->image=NULL ; 
	bijoux->image=IMG_Load("bijoux.png");
	bijoux->pos_image.x=4754 ; 
	bijoux->pos_image.y=440 ; 
	cd->image=NULL ; 
	cd->image=IMG_Load("cameradroite.png");
	cd->pos_image.x=1355 ; 
	cd->pos_image.y=0 ;
	cg->image=NULL ; 
	cg->image=IMG_Load("cameragauche.png");
	cg->pos_image.x=1355 ; 
	cg->pos_image.y=0 ; 
	cle->image=NULL ; 
	cle->image=IMG_Load("clé.png");
	cle->pos_image.x=364 ; 
	cle->pos_image.y=414 ; 
	dc->image=NULL ; 
	dc->image=IMG_Load("doorclose.png");
	dc->pos_image.x=5756 ; 
	dc->pos_image.y=241 ; 
	dop->image=NULL ; 
	dop->image=IMG_Load("dooropen.png");
	dop->pos_image.x=5756 ; 
	dop->pos_image.y=241 ; 
	money->image=NULL ; 
	money->image=IMG_Load("money.png");
	money->pos_image.x=2953 ; 
	money->pos_image.y=350 ; 
	password->image=NULL ; 
	password->image=IMG_Load("password.png");
	password->pos_image.x=5321 ; 
	password->pos_image.y=350 ; 
	camera.x=0;
	camera.y=0;
	camera.w=5760 ;
	camera.h=680;
        cd1->image=NULL ; 
	cd1->image=IMG_Load("cameradroite.png");
	cd1->pos_image.x=1355 ; 
	cd1->pos_image.y=0 ; 

	cg1->image=NULL ; 
	cg1->image=IMG_Load("cameragauche.png");
	cg1->pos_image.x=1355 ; 
	cg1->pos_image.y=0 ; 

	dc1->image=NULL ; 
	dc1->image=IMG_Load("doorclose.png");
	dc1->pos_image.x=5500 ; 
	dc1->pos_image.y=241 ; 

	dop1->image=NULL ; 
	dop1->image=IMG_Load("dooropen.png");
	dop1->pos_image.x=5500 ; 
	dop1->pos_image.y=241 ; 

        screen = SDL_SetVideoMode(5760,680, 32, SDL_HWSURFACE);
   while(continuer)
{
                SDL_BlitSurface(background,&camera,screen,NULL);
    		SDL_Flip(screen);
		SDL_Delay(100);
/*
        SDL_FillRect(screen, NULL,SDL_MapRGB(screen->format,0,0,0));	
	SDL_BlitSurface(cd1->image,NULL,screen,&cd1->pos_image);
	SDL_BlitSurface(dc1->image,NULL,screen,&dc1->pos_image);
	SDL_Flip(screen);
	usleep(3000000) ; 

	SDL_FillRect(screen, NULL,SDL_MapRGB(screen->format,0,0,0));	
	SDL_BlitSurface(dop1->image,NULL,screen,&dop1->pos_image);
	SDL_BlitSurface(cg1->image,NULL,screen,&cg1->pos_image);
	SDL_Flip(screen);
	usleep(3000000) ; */



/*
        SDL_BlitSurface(bijoux->image,NULL,screen,&bijoux->pos_image);
	SDL_BlitSurface(cd->image,NULL,screen,&cd->pos_image);
	SDL_BlitSurface(cg->image,NULL,screen,&cg->pos_image);
	SDL_BlitSurface(cle->image,NULL,screen,&cle->pos_image);
	SDL_BlitSurface(dc->image,NULL,screen,&dc->pos_image);
	SDL_BlitSurface(dop->image,NULL,screen,&dop->pos_image);
	SDL_BlitSurface(money->image,NULL,screen,&money->pos_image);
	SDL_BlitSurface(password->image,NULL,screen,&password->pos_image);
        SDL_Flip(screen);
*/
while(SDL_PollEvent(&e));
    switch(e.type)
    {
case SDL_QUIT:
continuer=0 ;     	
case SDL_KEYDOWN:
    	{
  	switch(e.key.keysym.sym)
		    	 {
                   case SDLK_LEFT:
                   camera.x-=100;
                   break;
                   case SDLK_RIGHT:
                   camera.x+=100;
                   break;
		    	 }
	
	}
	if(camera.x>=5760)
		camera.x=5760;
	if(camera.x<=0)
		camera.x=0;
	}	    	 

}

SDL_FreeSurface(screen);
return 0;
}
