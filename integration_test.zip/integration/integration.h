
#ifndef HEADER_H_INCLUDED
#define HEADER_H_INCLUDED
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
#include <unistd.h> 
typedef struct {
	SDL_Surface *personnage;
	SDL_Rect position_personnage;
	}personnage;

typedef struct ob 
{
	SDL_Surface *image;
	SDL_Rect pos_image;
}objet;
  

typedef struct al
{
 	SDL_Surface *fire;
	SDL_Rect position_fire;
	}fire;

typedef struct obj 
{
	SDL_Surface *image;
	SDL_Rect pos_image;
}entite;
 


#endif
