#include "jeux.h"

int main()
{
SDL_Surface*ecran=NULL,*img=NULL;
img=IMG_Load("background.png");
SDL_Rect positionecran;
positionecran.x=0;
positionecran.y=0;
ecran=SDL_SetVideoMode(1080,203,32,SDL_HWSURFACE |SDL_DOUBLEBUF);
int continuer=1;
while (continuer)
{
SDL_BlitSurface(img,NULL,ecran,&positionecran);
SDL_Flip(ecran);
}

SDL_FreeSurface(ecran);
return 0;

}
