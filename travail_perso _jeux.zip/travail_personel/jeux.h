#ifndef FONCTIONS_H_
#define FONCTIONS_H_
#include <stdio.h>
#include <stdlib.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
#include <SDL/SDL_ttf.h>
typedef struct maps
{
	SDL_Surface *affichage_map;
	int  speed_camera;
	SDL_Rect camera;
	double a;
	double v;
	double ajouter_speed;
        int buttoncamera;
        int mouvement_personnage;
        int changer;
}maps;


struct Circle
{
        int r;
}typedef Circle;



typedef struct rect_collision 
{

     int hauteur ; 
     int largeur ; 
     SDL_Rect position; 
} rect_collision;



typedef struct Radar
{
      SDL_Surface *affichage_hero ; 
      SDL_Rect position_hero ; 
      SDL_Rect frame ; 
}radar ;
typedef struct hero
{
        SDL_Rect position_hero;
        SDL_Rect position_aux;
        SDL_Surface *win_or_lose;
        SDL_Rect win_or_lose_position;
        SDL_Surface *affichage_hero;
        SDL_Rect position_map;
        int speed;
        int button;
}hero;

maps Initialiser_map (maps map);
hero Initialiser_Personnage (hero thief);
void Afficher_Personnage (hero *thief , SDL_Surface *ecran);
void deplacment_Personnage_clavier (hero *thief );
int  deplacement_aleatoire ( int positionmax, int positionmin   );
void animation_Personnage (hero *thief);
void scrolling (maps *map , SDL_Surface *ecran , hero *thief);
void radar_map (SDL_Surface *map ,hero *thief, radar *radar,SDL_Surface *ecran )  ; 
int Collisiontrigo(SDL_Rect position,SDL_Rect positioncercle,Circle C);
#endif /* FONCTIONS_H_ */

