#include <stdio.h>
#include <stdlib.h>
#include <SDL/SDL.h>
#include <math.h>
#include <time.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
#include <SDL/SDL_ttf.h>
#include <string.h>
#include "jeux.h"







void temp_affichage (hero *thief, temps *temp, int affichagetemp , SDL_Color rouge ,SDL_Surface *ecran )
{if (affichagetemp==0)
{temp->temp=TTF_RenderText_Blended(temp->police,temp->chaine,rouge);

temp->tempactuel=SDL_GetTicks();

if (temp->tempactuel- temp->tempprecedent >1000  )
{
temp->seconde1++;
temp->tempprecedent= temp->tempactuel;

}
if (temp->seconde1>9)
{
	temp->seconde1=0;
	temp->seconde2++;
}
if (temp->seconde2>=6)
{
	temp->seconde2=0;
	temp->minute1++;
}
if (temp->minute1>=9)
{
	temp->minute1=0;
	temp->minute2++;
}
if (temp->minute2>=6)
{
	temp->minute2=0;
	temp->heur1++;
}
if (temp->heur1>=9)
{
	temp->heur1=0;
	temp->heur2++;
}






printf(temp->chaine,"%d %d : %d %d : %d %d ",temp->heur2,temp->heur1,temp->minute2,temp->minute1,temp->seconde2,temp->seconde1);

SDL_BlitSurface(temp->temp,NULL,ecran,&temp->position_temp);
}

if (affichagetemp==1)
{



temp->temp=TTF_RenderText_Blended(temp->police,temp->chaine,rouge);
if (temp->seconded1!=0 || temp->seconded2!=0 || temp->minuted1!=0)
{temp->tempactuel=SDL_GetTicks();

if (temp->tempactuel- temp->tempprecedent >1000  )
{
temp->seconded1--;
temp->tempprecedent= temp->tempactuel;

}
if (temp->seconded1<0)
{
	temp->seconded1=9;
	temp->seconded2--;
}
if (temp->seconded2<0)
{
	temp->seconded2=5;
	temp->minuted1--;
}

}
else
{
thief->nombre_vie--;
temp->minuted1=2;

}





printf(temp->chaine,"%d %d : %d %d : %d %d ",temp->heurd2,temp->heurd1,temp->minuted2,temp->minuted1,temp->seconded2,temp->seconded1);

SDL_BlitSurface(temp->temp,NULL,ecran,&temp->position_temp);











}




}






















