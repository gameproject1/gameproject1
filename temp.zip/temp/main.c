#include <stdio.h>
#include <stdlib.h>
#include <SDL/SDL.h>
#include <math.h>
#include <time.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
#include <SDL/SDL_ttf.h>
#include <string.h>
#include "jeux.h"

int main()
{

	hero thief;
	temps temp;
	int conti=1;
	int affichagetemp;
	SDL_Colour rouge;
	SDL_Surface *ecran;
	SDL_Init(SDL_INIT_VIDEO);
	ecran = SDL_SetVideoMode(600,250,32, SDL_HWSURFACE);
temp =inisaliser_temp ( temp);
while(conti){
temp_affichage ( &thief,  &temp, affichagetemp , rouge , ecran );
SDL_Flip(ecran);
}
return 0;
}
