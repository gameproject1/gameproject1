
#include <stdio.h>
#include <stdlib.h>
#include <SDL/SDL.h>
#include <math.h>
#include <time.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
#include <SDL/SDL_ttf.h>
#include <string.h>
#include "jeux.h"






temps inisaliser_temp (temps temp)
{
temp.police=TTF_OpenFont("arial.ttf",300);
temp.heur1=0;
temp.minute1=0;
temp.seconde1=0;
temp.heur2=0;
temp.minute2=0;
temp.seconde2=0;
temp.tempactuel=0;
temp.temp=NULL;
temp.tempprecedent=0;
temp.position_temp.x=290;
temp.position_temp.y=100;
temp.heurd1=0;
temp.minuted1=2;
temp.seconded1=0;
temp.heurd2=0;
temp.minuted2=0;
temp.seconded2=0;

	return temp;
}
